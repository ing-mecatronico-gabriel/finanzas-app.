const crypto = require('crypto');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const config = require('../config');
const db = require('../db');

function generateUuid() {
  return crypto.randomUUID ? crypto.randomUUID() : crypto.randomBytes(16).toString('hex');
}

exports.register = async (req, res) => {
  try {
    const { name, email, password, currency = 'COP' } = req.body;

    if (!name || !email || !password) {
      return res.status(400).json({ success: false, error: 'Nombre, email y contraseña requeridos' });
    }

    const existing = await db.findOne('users', { email: email.toLowerCase() });
    if (existing) {
      return res.status(400).json({ success: false, error: 'El correo electrónico ya está registrado' });
    }

    const salt = await bcrypt.genSalt(10);
    const password_hash = await bcrypt.hash(password, salt);
    const userId = generateUuid();

    const newUser = await db.insert('users', {
      id: userId,
      name,
      email: email.toLowerCase(),
      password_hash,
      currency
    });

    // Crear cuentas por defecto del usuario para una experiencia inmediata
    const defaultAccounts = [
      { id: generateUuid(), user_id: userId, name: 'Efectivo', type: 'Efectivo', balance: 100000, currency, color: '#10b981', icon: 'money-bill-wave' },
      { id: generateUuid(), user_id: userId, name: 'Bancolombia', type: 'Bancaria', balance: 1500000, currency, color: '#2563eb', icon: 'landmark' },
      { id: generateUuid(), user_id: userId, name: 'Nequi', type: 'Nequi', balance: 350000, currency, color: '#8b5cf6', icon: 'mobile-alt' }
    ];

    for (const acc of defaultAccounts) {
      await db.insert('accounts', acc);
    }

    const token = jwt.sign(
      { id: newUser.id, email: newUser.email, name: newUser.name, currency: newUser.currency },
      config.jwtSecret,
      { expiresIn: config.jwtExpiresIn }
    );

    res.status(201).json({
      success: true,
      token,
      user: { id: newUser.id, name: newUser.name, email: newUser.email, currency: newUser.currency }
    });
  } catch (err) {
    console.error('Error en registro:', err);
    res.status(500).json({ success: false, error: 'Error interno en registro', details: err.message });
  }
};

exports.login = async (req, res) => {
  try {
    const { email, password } = req.body;

    if (!email || !password) {
      return res.status(400).json({ success: false, error: 'Email y contraseña requeridos' });
    }

    const user = await db.findOne('users', { email: email.toLowerCase() });
    if (!user) {
      return res.status(401).json({ success: false, error: 'Credenciales inválidas' });
    }

    const isMatch = await bcrypt.compare(password, user.password_hash);
    if (!isMatch) {
      return res.status(401).json({ success: false, error: 'Credenciales inválidas' });
    }

    const token = jwt.sign(
      { id: user.id, email: user.email, name: user.name, currency: user.currency },
      config.jwtSecret,
      { expiresIn: config.jwtExpiresIn }
    );

    res.json({
      success: true,
      token,
      user: { id: user.id, name: user.name, email: user.email, currency: user.currency }
    });
  } catch (err) {
    console.error('Error en login:', err);
    res.status(500).json({ success: false, error: 'Error interno en inicio de sesión' });
  }
};

exports.me = async (req, res) => {
  try {
    const user = await db.findOne('users', { id: req.user.id });
    if (!user) {
      return res.status(404).json({ success: false, error: 'Usuario no encontrado' });
    }

    res.json({
      success: true,
      user: { id: user.id, name: user.name, email: user.email, currency: user.currency }
    });
  } catch (err) {
    res.status(500).json({ success: false, error: 'Error consultando perfil' });
  }
};
